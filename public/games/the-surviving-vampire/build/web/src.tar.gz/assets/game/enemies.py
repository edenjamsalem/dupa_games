from game.settings import *
from game.projectiles import Orb
from game.surfs import BOSS_FRAMES, ORB_SURF
from game.audio import BONES_SOUND
from game.audio import IMPACT_SOUND, DEMON_SLAYED_SOUND, ORB_SOUND

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos, framedata, player, collision_sprites, game):
        super().__init__(game.all_sprites, game.enemy_sprites)
        self.game = game
        self.player = player
        self.type = framedata[0]
        self.frames = framedata[1]
        self.animation_direction = 'down'
        self.frame_index = 0
        self.image = self.frames['walk']['down'][0]
        self.animation_speed = 12

        self.rect = self.image.get_frect(center = pos)
        self.hitbox_rect = self.rect.inflate(-20, -40)
        self.collision_sprites = collision_sprites
        self.direction = pygame.Vector2()
        self.speed = 250
        self.death_time = 0
        self.death_duration = 500
        if self.type == 'skeleton':
            self.death_sound = BONES_SOUND
        else:
            self.death_sound = IMPACT_SOUND

    def animate(self, dt):
        statex = 'right' if self.direction.x > 0 else 'left'
        statey = 'down' if self.direction.y > 0 else 'up'
        self.animation_direction = statex if abs(self.direction.x) > abs(self.direction.y) else statey
        
        self.frame_index = self.frame_index + self.animation_speed * dt if self.direction else 0
        self.image = self.frames['walk'][self.animation_direction][int(self.frame_index) % len(self.frames['walk'][self.animation_direction])]

    def move(self, dt):
        player_pos = pygame.Vector2(self.player.rect.center)
        enemy_pos = pygame.Vector2(self.rect.center)
        self.direction = (player_pos - enemy_pos).normalize()

        # Stop enemies getting close to player when shield active
        if self.player.powerup_activated == 'shield' and (player_pos - enemy_pos).length() <= self.player.shield_range:
            return
        
        speed = self.speed
        
        # Half enemy speed when inside aura
        if self.player.aura and (player_pos - enemy_pos).length() <= self.player.aura.radius:
            speed = self.speed / 2

        self.hitbox_rect.x += self.direction.x * speed * dt
        if self.type != 'bat':
            self.collisions('horizontal')
        
        self.hitbox_rect.y += self.direction.y * speed * dt
        if self.type != 'bat':
            self.collisions('vertical')

        self.rect.center = self.hitbox_rect.center

    def collisions(self, direction):
        for sprite in self.collision_sprites:
            if sprite.rect.colliderect(self.hitbox_rect):
                if direction == 'horizontal':
                    if self.direction.x > 0:
                        self.hitbox_rect.right = sprite.rect.left
                    if self.direction.x < 0:
                        self.hitbox_rect.left = sprite.rect.right
                if direction == 'vertical':
                    if self.direction.y > 0:
                        self.hitbox_rect.bottom = sprite.rect.top
                    if self.direction.y < 0:
                        self.hitbox_rect.top = sprite.rect.bottom
    
    def set_mask_to_red(self):
       for x in range(self.image.get_width()):
           for y in range(self.image.get_height()):
               color = self.image.get_at((x, y))
               if color == (255, 255, 255):
                    self.image.set_at((x, y), (175, 0, 0))

    def destroy(self, hit_player=False):
        self.death_sound.play()
        self.game.enemy_sprites.remove(self)
        self.death_time = pygame.time.get_ticks()
        self.image = self.frames['dead'][self.animation_direction][0]

    def death_timer(self):
        if pygame.time.get_ticks() - self.death_time >= self.death_duration:
            self.kill()

    def update(self, dt):
        if self.death_time == 0:
            self.move(dt)
            self.animate(dt)
        else:
            self.death_timer()

BOSS_SPEED = 250

class Boss(pygame.sprite.Sprite):
    def __init__(self, pos, player, game):
        super().__init__(game.all_sprites, game.enemy_sprites)
        self.game = game
        self.lives = 25
        self.player = player
        self.type = 'boss'
        self.position_offset = [0, 1, 0, -1] # TODO: not sure what this is ??
        
        self.animation_speed = 9
        self.walk_frames = BOSS_FRAMES['walk']
        self.attack_frames = BOSS_FRAMES['attack']
        self.image = self.walk_frames['down'][0]
        self.frame_index = 0
        self.state = 'right'
        self.rect = self.image.get_frect(center = pos)
        self.direction = pygame.Vector2()
        self.speed = BOSS_SPEED
        
        self.can_shoot = True
        self.shoot_time = 0
        self.orb_cooldown = 400
        
        self.can_attack = False
        self.attack_time = pygame.time.get_ticks()
        self.attack_cooldown = 3000
        
        self.death_time = 0
        self.death_duration = 250
    
    def loop_frames(self, frames, dt):
        statex = 'right' if self.direction.x > 0 else 'left'
        statey = 'down' if self.direction.y > 0 else 'up'
        self.state = statex if abs(self.direction.x) > abs(self.direction.y) else statey
        
        self.frame_index = self.frame_index + self.animation_speed * dt if self.direction else 0
        self.image = frames[self.state][int(self.frame_index) % len(frames[self.state])]

    def animate(self, dt):
        if self.can_attack:
            self.speed = 0
            self.loop_frames(self.attack_frames, dt)
        else:
            self.speed = BOSS_SPEED
            self.loop_frames(self.walk_frames, dt)

    def attack_timer(self):
        current_time = pygame.time.get_ticks()
        if current_time - self.attack_time >= self.attack_cooldown:
            self.can_attack = not self.can_attack
            self.attack_time = current_time

    def move(self, dt):
        player_pos = pygame.Vector2(self.player.rect.center)
        enemy_pos = pygame.Vector2(self.rect.center)
        self.direction = (player_pos - enemy_pos).normalize()
        self.rect.center += self.direction * self.speed * dt

    def set_mask_to_red(self):
       for x in range(self.image.get_width()):
           for y in range(self.image.get_height()):
               color = self.image.get_at((x, y))
               if color == (255, 255, 255):
                    self.image.set_at((x, y), (175, 0, 0))

    def shoot(self):
        if self.can_shoot and self.can_attack:
            ORB_SOUND.play()
            Orb(ORB_SURF, self.rect.center, (pygame.math.Vector2(self.player.rect.center) - (pygame.math.Vector2(self.rect.center))).normalize(), (self.game.all_sprites, self.game.enemy_sprites))
            self.can_shoot = False
            self.shoot_time = pygame.time.get_ticks()
    
    def shoot_timer(self):
        if not self.can_shoot:
            current_time = pygame.time.get_ticks()
            if current_time - self.shoot_time >= self.orb_cooldown:
                self.can_shoot = True

    def destroy(self, hit_player=False):
        self.game.boss_spawn_timer.activate()
        self.game.enemy_sprites.remove(self)
        self.death_time = pygame.time.get_ticks()
        self.image = pygame.mask.from_surface(self.image).to_surface()
        self.image.set_colorkey('black')
        DEMON_SLAYED_SOUND.play()
        if hit_player:
            self.set_mask_to_red()

    def death_timer(self):
        if pygame.time.get_ticks() - self.death_time >= self.death_duration:
            self.kill()

    def update(self, dt):
        if self.death_time == 0:
            self.shoot()
            self.shoot_timer()
            self.attack_timer()
            self.move(dt)
            self.animate(dt)
        else:
            self.death_timer()