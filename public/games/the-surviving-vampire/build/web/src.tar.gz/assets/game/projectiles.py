from game.settings import *
from math import atan2, degrees
from game.surfs import EXPLOSION_FRAMES
from game.audio import EXPLOSION_SOUND

class Bullet(pygame.sprite.Sprite):
    def __init__(self, surf, pos, direction, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_frect(center = pos) 
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 2000
        self.direction = direction
        self.speed = 1600
        self.rotate()
    
    def rotate(self):
        angle = degrees(atan2(self.direction.x, self.direction.y)) - 90
        if self.direction.x > 0:
            self.image = pygame.transform.rotozoom(self.image, angle, 1)
        else:
            self.image = pygame.transform.rotozoom(self.image, abs(angle), 1)
            self.image = pygame.transform.flip(self.image, False, True)

    def update(self, dt):
        self.rect.center += self.direction * self.speed * dt
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()

class Laser(pygame.sprite.Sprite):
    def __init__(self, surf, pos, orientation, groups):
        super().__init__(groups)
        self.angle = orientation.angle_to(pygame.math.Vector2(0, 1))
        self.image = pygame.transform.rotate(surf, self.angle)
        self.rect = self.image.get_frect(center = pos)
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 1
        self.direction = pygame.math.Vector2(0,0)
    
    def update(self, dt):
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()

class Flame(pygame.sprite.Sprite):
    def __init__(self, frames, pos, groups):
        super().__init__(groups)
        self.image = frames[0]
        self.rect = self.image.get_frect(center = pos)
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 2500
        self.frames = frames
        self.frame_index = 0
        self.animation_speed = 12

    def animate(self, dt):
        self.frame_index += self.animation_speed * dt
        self.image = self.frames[int(self.frame_index) % len(self.frames)]
    
    def update(self, dt):
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()
        self.animate(dt)

class Mine(pygame.sprite.Sprite):
    def __init__(self, surf, pos, groups, game):
        super().__init__(groups)
        self.image = surf
        self.game = game
        self.rect = self.image.get_frect(center = pos)
        self.explosion_frames = EXPLOSION_FRAMES
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 10000
        self.explosion_sound = EXPLOSION_SOUND

    def enemy_collisions(self):
        collision_sprites = pygame.sprite.spritecollide(self, self.game.enemy_sprites, False, pygame.sprite.collide_mask)
        if collision_sprites:
            Explosion(self.explosion_frames, self.rect.center, (self.game.all_sprites, self.game.explosion_sprites))
            self.explosion_sound.play()
            self.kill()

    def update(self, _):
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()
        self.enemy_collisions()

class Explosion(pygame.sprite.Sprite):
    def __init__(self, frames, pos, groups):
        super().__init__(groups)
        self.image = frames[0]
        self.rect = self.image.get_frect(center = pos)
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 250
        self.frames = frames
        self.frame_index = 0
        self.animation_speed = 25

    def animate(self, dt):
        self.frame_index += self.animation_speed * dt
        self.image = self.frames[int(self.frame_index) % len(self.frames)]
    
    def update(self, dt):
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()
        self.animate(dt)

        

class Orb(pygame.sprite.Sprite):
    def __init__(self, surf, pos, direction, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_frect(center = pos) 
        self.spawn_time = pygame.time.get_ticks()
        self.lifetime = 5000
        self.direction = direction
        self.speed = 750
        self.type = 'orb'

    def update(self, dt):
        self.rect.center += self.direction * self.speed * dt
        if pygame.time.get_ticks() - self.spawn_time >= self.lifetime:
            self.kill()